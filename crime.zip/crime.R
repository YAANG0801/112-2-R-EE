library(dplyr)

# 假设 df1、df2、df3 和 df4 是你的四个数据框

# 合并四个数据框
merged_df <- bind_rows(X112年1_3月, X112年10_12月, X112年4_6月, X112年7_9月)

# 查看合并后的数据框
print(merged_df)


# 对合并后的数据框按国籍和犯罪种类进行分组，并计算每个分组的行数
crime_counts <- merged_df %>%
  group_by(country, type) %>%
  summarise(犯罪數量 = n())

# 计算所有犯罪种类的数量总和
total_crime_count <- sum(crime_counts$犯罪數量, na.rm = TRUE)

# 创建包含总犯罪数量的数据框
total_crime_df <- data.frame(總犯罪數量 = total_crime_count)

library(dplyr)

# 假设 df 是你的数据框

# 调整列顺序
df <- select(merged_df, country, type, oc_dt, oc_p1)

# 查看结果
print(df)

library(dplyr)

# 假设 df 是你的数据框，包含了 country 列

# 使用 group_by() 和 summarise() 统计每个国家的犯罪数量
crime_counts <- df %>%
  group_by(country) %>%
  summarise(crime_count = n())

# 查看结果
print(crime_counts)
# 假设 df 是你的数据框，包含了 county 和 township 列

library(tidyr)

# 假设 df 是你的数据框，包含了 oc_p1 列

# 使用 separate() 函数将 oc_p1 列分割为两列
df <- separate(df, oc_p1, into = c("county", "township"), sep = "(?<=[市縣])")

# 查看结果
print(df)

# 使用正则表达式将县市名称移到 township 列下的空格中
df$township <- gsub(".*?(市|縣)(.*)", "\\1\\2", df$county)
df$county <- gsub("(.*)(市|縣).*", "\\1\\2", df$county)

# 查看结果
print(df)


library(dplyr)

# 假设 df 是你的数据框，包含了 country、type 和 犯罪数量 列

# 使用 group_by() 函数按照 country 和 type 分组
# 使用 mutate() 函数计算每种犯罪类型在每个国家中的比例
ratio <- crime_counts %>%
  group_by(country) %>%
  mutate(crime_percentage = 犯罪數量 / sum(犯罪數量) * 100)

# 查看结果
print(df)



# 使用stringr套件中的str_extract函数提取中文部分
library(stringr)

# 提取中文部分作为新的國家欄位
crime_totals$國家 <- str_extract(crime_totals$country, "[^a-zA-Z]+")

# 移除原始的country欄位
crime_totals <- crime_totals %>%
  select(-country)

# 预览数据框
glimpse(crime_totals)

crime_totals <- crime_totals %>%
  select(國家, total_crimes)

# 預覽資料框
glimpse(crime_totals)

colnames(FOREIGN)[colnames(FOREIGN) == "國籍"] <- "國家"
colnames(FOREIGN)[colnames(FOREIGN) == "2024年[1]"] <- "2024年人數"
FOREIGN <- FOREIGN[, !(names(FOREIGN) %in% c("排名"))]

# 使用 dplyr 的 bind_rows 函數進行垂直合併
merged_data <- bind_rows(crime_totals, FOREIGN)

# 預覽合併後的資料框
glimpse(merged_data)

merged_data <- full_join(crime_totals, FOREIGN, by = "國家")

# 將缺失的值替換為 N/A
merged_data[is.na(merged_data)] <- "N/A"

# 預覽合併後的資料框
glimpse(merged_data)

# 計算犯罪比例
merged_data$犯罪比例 <- merged_data$total_crimes / merged_data$`2024年人數`

# 預覽計算後的資料框
glimpse(merged_data)


write_csv(mer, "output.csv")